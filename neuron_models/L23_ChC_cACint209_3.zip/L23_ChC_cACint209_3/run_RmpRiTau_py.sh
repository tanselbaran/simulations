nrnivmodl ./mechanisms
./run_RmpRiTau.py "$@"
